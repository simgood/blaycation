# blaycation to do


## Back End

- Build a Blaycation page needs a Design MAKEOVER


## CMS Side

- Poker Page
- News Page
- Corporate Getaways Page
